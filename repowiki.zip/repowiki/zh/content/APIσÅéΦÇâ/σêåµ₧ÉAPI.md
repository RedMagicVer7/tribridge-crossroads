# 分析API

<cite>
**本文档中引用的文件**  
- [analytics.ts](file://backend/src/routes/analytics.ts)
- [Analytics.tsx](file://src/components/Analytics/Analytics.tsx)
- [transactionService.ts](file://src/services/transactionService.ts)
- [RiskMonitoring.tsx](file://src/components/Risk/RiskMonitoring.tsx)
- [PerformanceMonitor.tsx](file://src/components/Performance/PerformanceMonitor.tsx)
</cite>

## 目录
1. [简介](#简介)
2. [交易量统计API](#交易量统计api)
3. [用户行为分析](#用户行为分析)
4. [风险指标API](#风险指标api)
5. [性能监控API](#性能监控api)
6. [实时监控数据流](#实时监控数据流)
7. [审计日志与导出功能](#审计日志与导出功能)
8. [数据采样与查询优化](#数据采样与查询优化)

## 简介
分析API为系统提供全面的数据洞察功能，涵盖交易量统计、用户行为分析、风险评估和性能监控等核心维度。该API通过多个端点为管理员和运营团队提供实时和历史数据分析能力，支持决策制定和系统优化。前端组件通过可视化图表展示关键指标，包括交易趋势、货币分布、风险评分和系统性能。整个系统设计注重实时性、可扩展性和安全性，确保数据分析的准确性和及时性。

## 交易量统计api
交易量统计API提供详细的交易聚合数据，支持不同时间范围的查询。核心端点`GET /api/analytics/transactions`通过`period`查询参数指定统计周期，支持`24h`、`7d`、`30d`等选项。返回的聚合数据包含总交易额、平均手续费、成功率等关键指标。

```mermaid
flowchart TD
Client["客户端请求"] --> |GET /api/analytics/transactions?period=24h| API["分析API"]
API --> Validation["参数验证"]
Validation --> Query["查询交易数据"]
Query --> Aggregate["数据聚合计算"]
Aggregate --> Format["格式化响应"]
Format --> Response["返回JSON数据"]
```

**图表来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)

**本节来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)
- [transactionService.ts](file://src/services/transactionService.ts#L311-L363)

## 用户行为分析
用户行为分析端点提供用户活跃度和交易模式的深入洞察。通过`GET /api/analytics/user-activity`接口，系统返回用户分段数据、新用户增长和留存率等关键指标。这些数据帮助识别高价值用户群体和优化用户体验。

```mermaid
erDiagram
USER_ACTIVITY {
string period PK
integer daily_active_users
integer weekly_active_users
integer monthly_active_users
integer new_users_today
integer new_users_week
integer new_users_month
float retention_rate_day1
float retention_rate_day7
float retention_rate_day30
}
USER_SEGMENT {
string segment PK
integer count
float percentage
}
USER_ACTIVITY ||--o{ USER_SEGMENT : 包含
```

**图表来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)

**本节来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)

## 风险指标api
风险评分API通过多维度指标评估系统风险状况。输入特征包括交易频率、金额分布和地址聚类等行为模式。系统计算综合风险评分（0-100分），输出风险等级（低、中、高）和具体风险因素分析。

```mermaid
classDiagram
class RiskMetric {
+string id
+string name
+number value
+number threshold
+string status
+string trend
+string description
}
class RiskAnalysis {
+string period
+string overallRisk
+number riskScore
+RiskMetric[] factors
+Alert[] alerts
+string[] recommendations
}
RiskAnalysis --> RiskMetric : 包含
RiskAnalysis --> Alert : 生成
```

**图表来源**  
- [RiskMonitoring.tsx](file://src/components/Risk/RiskMonitoring.tsx#L28-L331)

**本节来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)
- [RiskMonitoring.tsx](file://src/components/Risk/RiskMonitoring.tsx#L28-L331)

## 性能监控api
性能监控API提供系统运行状况的实时视图。通过`GET /api/analytics/performance`端点，返回响应时间、吞吐量、错误率和可用性等关键性能指标。这些数据帮助运维团队及时发现和解决性能瓶颈。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant API as "分析API"
participant Monitor as "监控系统"
participant DB as "数据库"
Client->>API : GET /api/analytics/performance?period=24h
API->>Monitor : 获取实时性能数据
API->>DB : 查询历史性能数据
DB-->>API : 返回聚合数据
Monitor-->>API : 返回实时指标
API->>API : 合并数据并格式化
API-->>Client : 返回性能指标JSON
```

**图表来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)
- [PerformanceMonitor.tsx](file://src/components/Performance/PerformanceMonitor.tsx#L28-L387)

**本节来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)
- [PerformanceMonitor.tsx](file://src/components/Performance/PerformanceMonitor.tsx#L28-L387)

## 实时监控数据流
实时监控数据流通过Analytics组件实现可视化展示。系统每5秒更新一次性能指标，每30秒更新风险监控数据。前端使用WebSocket或轮询机制获取最新数据，并通过动态图表实时反映系统状态。

```mermaid
flowchart LR
DataSources["数据源<br>交易日志、系统指标"] --> DataPipeline["数据管道"]
DataPipeline --> RealtimeDB["实时数据库<br>Redis"]
RealtimeDB --> API["分析API"]
API --> Frontend["前端组件"]
Frontend --> Visualization["可视化图表<br>趋势图、仪表盘"]
Visualization --> Users["管理员和运营团队"]
```

**图表来源**  
- [Analytics.tsx](file://src/components/Analytics/Analytics.tsx#L47-L402)
- [PerformanceMonitor.tsx](file://src/components/Performance/PerformanceMonitor.tsx#L28-L387)

**本节来源**  
- [Analytics.tsx](file://src/components/Analytics/Analytics.tsx#L47-L402)
- [PerformanceMonitor.tsx](file://src/components/Performance/PerformanceMonitor.tsx#L28-L387)

## 审计日志与导出功能
管理员访问的审计日志查询接口提供全面的操作记录追踪。通过`POST /api/analytics/export`端点，支持将分析报告导出为PDF、Excel或CSV格式。系统记录所有导出操作，确保审计完整性。

```mermaid
flowchart TD
Admin["管理员"] --> |POST /api/analytics/export| ExportAPI["导出API"]
ExportAPI --> Validation["权限和参数验证"]
Validation --> Report["生成报告"]
Report --> Storage["临时存储"]
Storage --> Notification["发送完成通知"]
Notification --> Download["提供下载链接"]
ExportAPI --> AuditLog["记录审计日志"]
```

**图表来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)

**本节来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)

## 数据采样与查询优化
系统采用数据采样策略和查询性能优化技术确保分析API的高效运行。对于大规模数据集，系统使用预聚合和缓存机制。查询优化建议包括合理设置时间范围、使用索引字段和分页处理大量结果。

```mermaid
flowchart TD
Query["查询请求"] --> Optimization["优化策略"]
Optimization --> |小数据集| DirectQuery["直接查询"]
Optimization --> |大数据集| Sampling["数据采样"]
Optimization --> |频繁查询| Caching["结果缓存"]
Optimization --> |复杂聚合| PreAggregation["预聚合"]
DirectQuery --> Result["返回结果"]
Sampling --> Result
Caching --> Result
PreAggregation --> Result
```

**图表来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)
- [transactionService.ts](file://src/services/transactionService.ts#L311-L363)

**本节来源**  
- [analytics.ts](file://backend/src/routes/analytics.ts#L1-L423)
- [transactionService.ts](file://src/services/transactionService.ts#L311-L363)