# API参考

<cite>
**本文档中引用的文件**  
- [auth.ts](file://backend/src/routes/auth.ts)
- [kyc.ts](file://backend/src/routes/kyc.ts)
- [transaction.ts](file://backend/src/routes/transaction.ts)
- [blockchain.ts](file://backend/src/routes/blockchain.ts)
- [user.ts](file://backend/src/routes/user.ts)
- [settlement.ts](file://backend/src/routes/settlement.ts)
- [analytics.ts](file://backend/src/routes/analytics.ts)
- [auth.ts](file://pages/api/auth/[...auth].ts)
- [health.ts](file://pages/api/health.ts)
- [route.ts](file://src/app/api/wallet/balances/route.ts)
- [route.ts](file://src/app/api/wallet/transaction/route.ts)
- [auth.ts](file://backend/src/middleware/auth.ts)
- [apiKey.ts](file://backend/src/middleware/apiKey.ts)
- [errorHandler.ts](file://backend/src/middleware/errorHandler.ts)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概述](#架构概述)
5. [详细组件分析](#详细组件分析)
6. [依赖分析](#依赖分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介
本API参考文档为TriBridge平台提供完整的公开接口说明。文档涵盖后端RESTful API和Next.js服务端路由，详细描述了每个端点的HTTP方法、URL路径、请求头、请求体Schema和响应格式。特别说明了JWT认证流程和API密钥验证机制。文档区分了内部服务API与外部用户API的访问控制策略，并为每个端点提供了curl示例和JavaScript调用示例。包含错误代码表及其解决方案，以及API版本控制策略和未来扩展规划。

## 项目结构
TriBridge平台采用前后端分离架构，后端API基于Express框架实现，前端基于Next.js构建。API路由分为两类：后端Express路由和Next.js API路由。后端路由位于`backend/src/routes`目录，包括认证、KYC、交易、区块链、用户管理、清算和分析等模块。Next.js API路由位于`pages/api`和`src/app/api`目录，主要处理钱包相关的服务端逻辑。

```mermaid
graph TB
subgraph "前端"
NextJS[Next.js应用]
Pages["pages/"]
AppAPI["src/app/api/"]
end
subgraph "后端"
Express[Express服务器]
Routes["backend/src/routes/"]
Middleware["backend/src/middleware/"]
Services["backend/src/services/"]
end
NextJS --> Express
Pages --> Express
AppAPI --> Express
```

**图示来源**
- [backend/src/routes](file://backend/src/routes)
- [pages/api](file://pages/api)
- [src/app/api](file://src/app/api)

**本节来源**
- [backend/src/routes](file://backend/src/routes)
- [pages/api](file://pages/api)
- [src/app/api](file://src/app/api)

## 核心组件
TriBridge平台的核心组件包括认证系统、KYC验证、跨链交易、区块链交互、用户管理、清算服务和分析系统。这些组件通过RESTful API对外提供服务，采用JWT进行身份验证，API密钥进行访问控制。所有API端点都遵循统一的响应格式，包含success、data、error等字段。

**本节来源**
- [auth.ts](file://backend/src/routes/auth.ts)
- [kyc.ts](file://backend/src/routes/kyc.ts)
- [transaction.ts](file://backend/src/routes/transaction.ts)

## 架构概述
TriBridge平台采用分层架构设计，包括API网关层、业务逻辑层、服务层和数据访问层。API网关层处理身份验证、速率限制和请求路由。业务逻辑层实现核心业务功能，如交易处理、清算和KYC验证。服务层封装区块链交互、数据库操作和第三方服务集成。整个系统通过JWT和API密钥双重认证机制确保安全性。

```mermaid
graph TD
Client[客户端]
Gateway[API网关]
Business[业务逻辑层]
Service[服务层]
Data[数据访问层]
Client --> Gateway
Gateway --> Business
Business --> Service
Service --> Data
Gateway -.-> Auth[认证中间件]
Gateway -.-> RateLimit[速率限制]
Business -.-> Validation[数据验证]
Service -.-> Blockchain[区块链服务]
Service -.-> Database[数据库服务]
```

**图示来源**
- [backend/src/middleware/auth.ts](file://backend/src/middleware/auth.ts)
- [backend/src/middleware/apiKey.ts](file://backend/src/middleware/apiKey.ts)
- [backend/src/services](file://backend/src/services)

## 详细组件分析

### 认证系统分析
认证系统提供用户注册、登录和令牌刷新功能。采用JWT进行身份验证，密码使用bcrypt加密存储。系统支持可选的身份验证中间件，允许某些公开接口在无令牌情况下访问。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant AuthAPI as "认证API"
participant JWT as "JWT服务"
Client->>AuthAPI : POST /auth/register
AuthAPI->>AuthAPI : 验证输入
AuthAPI->>AuthAPI : 密码加密
AuthAPI->>JWT : 生成JWT令牌
JWT-->>AuthAPI : 访问令牌
AuthAPI-->>Client : 201 Created
Client->>AuthAPI : POST /auth/login
AuthAPI->>AuthAPI : 验证凭据
AuthAPI->>JWT : 生成JWT令牌
JWT-->>AuthAPI : 访问令牌
AuthAPI-->>Client : 200 OK
Client->>AuthAPI : POST /auth/refresh
AuthAPI->>JWT : 验证刷新令牌
JWT-->>AuthAPI : 新的访问令牌
AuthAPI-->>Client : 200 OK
```

**图示来源**
- [auth.ts](file://backend/src/routes/auth.ts)
- [pages/api/auth/[...auth].ts](file://pages/api/auth/[...auth].ts)

**本节来源**
- [auth.ts](file://backend/src/routes/auth.ts)
- [pages/api/auth/[...auth].ts](file://pages/api/auth/[...auth].ts)

### KYC验证分析
KYC系统处理用户身份验证请求，支持提交KYC申请、查询状态、上传文档和获取历史记录。系统集成第三方KYC服务提供商，通过webhook接收状态更新。

```mermaid
flowchart TD
Start([提交KYC申请]) --> Validate["验证用户身份"]
Validate --> Check["检查必要信息"]
Check --> |完整| Submit["提交到KYC服务"]
Check --> |缺失| ReturnError["返回400错误"]
Submit --> Store["存储KYC请求"]
Store --> Notify["通知用户"]
Notify --> End([返回成功响应])
ReturnError --> End
```

**图示来源**
- [kyc.ts](file://backend/src/routes/kyc.ts)
- [kycService.ts](file://backend/src/services/kycService.ts)

**本节来源**
- [kyc.ts](file://backend/src/routes/kyc.ts)

### 交易系统分析
交易系统处理跨链和同链交易，支持创建、执行、查询和取消交易。系统提供详细的交易状态跟踪和时间线记录。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant TransactionAPI as "交易API"
participant MultiChain as "多链服务"
Client->>TransactionAPI : POST /transactions
TransactionAPI->>TransactionAPI : 验证参数
TransactionAPI->>TransactionAPI : 创建交易记录
TransactionAPI-->>Client : 201 Created
Client->>TransactionAPI : POST /transactions/{id}/execute
TransactionAPI->>MultiChain : 执行跨链转移
MultiChain-->>TransactionAPI : 交易结果
TransactionAPI->>TransactionAPI : 更新交易状态
TransactionAPI-->>Client : 200 OK
```

**图示来源**
- [transaction.ts](file://backend/src/routes/transaction.ts)
- [multiChainService.ts](file://backend/src/services/multiChainService.ts)

**本节来源**
- [transaction.ts](file://backend/src/routes/transaction.ts)

### 区块链交互分析
区块链服务提供对支持的区块链网络的查询和交互功能，包括余额查询、地址验证、费用估算和网络状态检查。

```mermaid
classDiagram
class BlockchainService {
+getSupportedChains() Chain[]
+getChainConfig(chainName) ChainConfig
+getStablecoinBalance(chain, token, address) string
+validateAddress(chain, address) boolean
+estimateFee(chain, token, amount, from, to) FeeEstimate
}
class Chain {
+name : string
+rpcUrl : string
+explorerUrl : string
+nativeToken : string
+chainId : number
}
class FeeEstimate {
+estimatedFee : string
+gasPrice : string
+gasLimit : string
+estimatedTime : string
}
BlockchainService --> Chain : "支持"
BlockchainService --> FeeEstimate : "返回"
```

**图示来源**
- [blockchain.ts](file://backend/src/routes/blockchain.ts)
- [BlockchainService.ts](file://backend/src/services/BlockchainService.ts)

**本节来源**
- [blockchain.ts](file://backend/src/routes/blockchain.ts)

### 用户管理系统分析
用户管理系统处理用户资料管理、钱包管理和偏好设置。系统支持多钱包管理，允许用户添加、删除和设置默认钱包。

```mermaid
flowchart TD
A[获取用户资料] --> B{已认证?}
B --> |是| C[查询数据库]
B --> |否| D[返回401]
C --> E[返回用户数据]
F[更新用户资料] --> G{已认证?}
G --> |是| H[验证输入]
H --> I[更新数据库]
I --> J[返回成功]
G --> |否| D
K[管理钱包] --> L{已认证?}
L --> |是| M[执行钱包操作]
M --> N[返回结果]
L --> |否| D
```

**图示来源**
- [user.ts](file://backend/src/routes/user.ts)
- [database.ts](file://backend/src/services/database.ts)

**本节来源**
- [user.ts](file://backend/src/routes/user.ts)

### 清算服务分析
清算服务处理跨链资产结算，提供订单创建、状态跟踪、统计和路径查询功能。系统支持滑点设置和多步清算流程。

```mermaid
sequenceDiagram
participant Client as "客户端"
participant SettlementAPI as "清算API"
participant SettlementEngine as "清算引擎"
Client->>SettlementAPI : POST /settlement/orders
SettlementAPI->>SettlementAPI : 验证参数
SettlementAPI->>SettlementAPI : 创建清算订单
SettlementAPI-->>Client : 201 Created
SettlementEngine->>SettlementEngine : 执行清算步骤
SettlementEngine->>SettlementAPI : 更新订单状态
SettlementAPI->>Client : 发送状态更新
```

**图示来源**
- [settlement.ts](file://backend/src/routes/settlement.ts)
- [multiChainService.ts](file://backend/src/services/multiChainService.ts)

**本节来源**
- [settlement.ts](file://backend/src/routes/settlement.ts)

### 分析系统分析
分析系统提供交易统计、用户活跃度、性能指标和风险分析。支持数据导出和实时监控。

```mermaid
flowchart TD
A[分析API] --> B[仪表板统计]
A --> C[交易量趋势]
A --> D[用户活跃度]
A --> E[性能指标]
A --> F[风险分析]
A --> G[报告导出]
A --> H[实时统计]
B --> I[数据库查询]
C --> I
D --> I
E --> J[监控系统]
F --> K[风险评估]
G --> L[报告生成]
H --> M[实时数据流]
```

**图示来源**
- [analytics.ts](file://backend/src/routes/analytics.ts)
- [redis.ts](file://backend/src/services/redis.ts)

**本节来源**
- [analytics.ts](file://backend/src/routes/analytics.ts)

### Next.js API路由分析
Next.js API路由处理前端钱包相关的服务端逻辑，包括余额查询和交易处理。这些路由在服务器端执行，确保敏感操作的安全性。

```mermaid
sequenceDiagram
participant Client as "前端"
participant NextJSAPI as "Next.js API"
participant Blockchain as "区块链网络"
Client->>NextJSAPI : POST /api/wallet/balances
NextJSAPI->>NextJSAPI : 验证地址
NextJSAPI->>Blockchain : 查询余额
Blockchain-->>NextJSAPI : 余额数据
NextJSAPI-->>Client : 返回余额
Client->>NextJSAPI : POST /api/wallet/transaction
NextJSAPI->>NextJSAPI : 验证交易参数
NextJSAPI->>NextJSAPI : 处理交易
NextJSAPI-->>Client : 返回交易详情
```

**图示来源**
- [route.ts](file://src/app/api/wallet/balances/route.ts)
- [route.ts](file://src/app/api/wallet/transaction/route.ts)
- [ethers](https://docs.ethers.org/)

**本节来源**
- [route.ts](file://src/app/api/wallet/balances/route.ts)
- [route.ts](file://src/app/api/wallet/transaction/route.ts)

## 依赖分析
TriBridge平台的组件之间存在明确的依赖关系。API路由依赖中间件进行认证和错误处理，业务逻辑依赖服务层进行数据访问和区块链交互。系统采用松耦合设计，各组件通过清晰的接口进行通信。

```mermaid
graph TD
AuthAPI[认证API] --> AuthMiddleware[认证中间件]
KYCAPI[KYC API] --> AuthMiddleware
TransactionAPI[交易API] --> AuthMiddleware
UserAPI[用户API] --> AuthMiddleware
SettlementAPI[清算API] --> AuthMiddleware
AnalyticsAPI[分析API] --> AuthMiddleware
AuthMiddleware --> JWT[JWT服务]
AuthMiddleware --> APIKey[API密钥验证]
TransactionAPI --> MultiChainService[多链服务]
SettlementAPI --> MultiChainService
BlockchainAPI --> MultiChainService
MultiChainService --> Database[数据库服务]
MultiChainService --> Redis[Redis服务]
AllAPIs --> ErrorHandler[错误处理中间件]
```

**图示来源**
- [backend/src/middleware](file://backend/src/middleware)
- [backend/src/services](file://backend/src/services)
- [backend/src/routes](file://backend/src/routes)

**本节来源**
- [backend/src/middleware](file://backend/src/middleware)
- [backend/src/services](file://backend/src/services)

## 性能考虑
TriBridge平台在设计时充分考虑了性能因素。API网关层实现了基于API密钥的速率限制，防止滥用。服务层使用Redis缓存频繁访问的数据，减少数据库查询。区块链交互采用异步处理，避免阻塞主线程。系统监控关键性能指标，包括响应时间、吞吐量和错误率。

**本节来源**
- [backend/src/middleware/apiKey.ts](file://backend/src/middleware/apiKey.ts)
- [backend/src/services/redis.ts](file://backend/src/services/redis.ts)
- [analytics.ts](file://backend/src/routes/analytics.ts)

## 故障排除指南
当API调用出现问题时，首先检查响应状态码和错误信息。常见问题包括认证失败、参数验证错误和速率限制。对于401错误，检查JWT令牌是否有效。对于400错误，验证请求体格式是否正确。对于429错误，等待速率限制窗口重置。所有错误响应都包含详细的错误信息和时间戳，便于调试。

**本节来源**
- [errorHandler.ts](file://backend/src/middleware/errorHandler.ts)
- [auth.ts](file://backend/src/middleware/auth.ts)
- [apiKey.ts](file://backend/src/middleware/apiKey.ts)

## 结论
TriBridge平台的API设计遵循RESTful原则，提供清晰、一致的接口。系统采用JWT和API密钥双重认证机制，确保安全性。通过中间件实现认证、授权和错误处理，保持业务逻辑的纯净。未来计划引入API版本控制，通过URL路径或请求头支持多版本共存。同时，考虑实现GraphQL接口，为客户端提供更灵活的数据查询能力。