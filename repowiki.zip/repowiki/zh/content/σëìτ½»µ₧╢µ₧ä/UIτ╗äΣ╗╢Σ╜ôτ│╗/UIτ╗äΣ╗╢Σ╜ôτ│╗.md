# UI组件体系

<cite>
**本文档引用的文件**  
- [button.tsx](file://src/components/ui/button.tsx)
- [card.tsx](file://src/components/ui/card.tsx)
- [dialog.tsx](file://src/components/ui/dialog.tsx)
- [form.tsx](file://src/components/ui/form.tsx)
- [tooltip.tsx](file://src/components/ui/tooltip.tsx)
- [sheet.tsx](file://src/components/ui/sheet.tsx)
- [accordion.tsx](file://src/components/ui/accordion.tsx)
- [alert-dialog.tsx](file://src/components/ui/alert-dialog.tsx)
- [Header.tsx](file://src/components/Layout/Header.tsx)
- [SiteNavigation.tsx](file://src/components/Layout/SiteNavigation.tsx)
- [MobileMenu.tsx](file://src/components/Layout/MobileMenu.tsx)
- [components.json](file://components.json)
- [tailwind.config.ts](file://tailwind.config.ts)
- [utils.ts](file://src/lib/utils.ts)
- [use-toast.ts](file://src/hooks/use-toast.ts)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概览](#架构概览)
5. [详细组件分析](#详细组件分析)
6. [依赖分析](#依赖分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 简介
本文档详细描述了ShadCN/UI组件库在TriBridge项目中的集成实现。文档涵盖基础UI组件的封装设计、可访问性特性、响应式模式和主题定制机制。通过具体示例展示如何组合基础组件构建复杂业务界面，并说明组件的props接口、事件处理和样式覆盖方法。特别针对布局组件如Header和Sidebar，阐述其在多页面应用中的复用模式和状态同步机制。

## 项目结构

```mermaid
graph TD
A[src] --> B[components]
A --> C[lib]
A --> D[hooks]
A --> E[config]
B --> F[ui] --> G[基础组件]
B --> H[Layout] --> I[Header]
B --> H --> J[MobileMenu]
B --> H --> K[SiteNavigation]
C --> L[utils.ts]
D --> M[use-toast.ts]
```

**图示来源**  
- [src/components](file://src/components)
- [src/lib](file://src/lib)
- [src/hooks](file://src/hooks)

**本节来源**  
- [src](file://src)

## 核心组件

本文档涵盖的核心UI组件包括按钮、表单、卡片、对话框等基础元素，以及Header、Sidebar等布局组件。所有组件均基于ShadCN/UI进行封装，遵循统一的设计系统规范。组件实现注重可访问性（a11y），支持键盘导航和屏幕阅读器，并通过Tailwind CSS实现响应式设计。主题定制通过CSS变量实现，支持深色模式切换。

**本节来源**  
- [button.tsx](file://src/components/ui/button.tsx#L1-L48)
- [card.tsx](file://src/components/ui/card.tsx#L1-L44)
- [dialog.tsx](file://src/components/ui/dialog.tsx#L1-L96)

## 架构概览

```mermaid
graph TB
subgraph "UI组件层"
Button["按钮组件"]
Card["卡片组件"]
Dialog["对话框组件"]
Form["表单组件"]
end
subgraph "工具层"
Utils["工具函数"]
Toast["通知系统"]
Hook["自定义Hook"]
end
subgraph "样式层"
Tailwind["Tailwind CSS"]
CSSVars["CSS变量"]
Theme["主题系统"]
end
Button --> Tailwind
Card --> Tailwind
Dialog --> Tailwind
Form --> Tailwind
Utils --> Tailwind
Toast --> Utils
Hook --> Utils
Tailwind --> CSSVars
Theme --> CSSVars
```

**图示来源**  
- [tailwind.config.ts](file://tailwind.config.ts#L1-L121)
- [utils.ts](file://src/lib/utils.ts#L1-L7)
- [use-toast.ts](file://src/hooks/use-toast.ts#L1-L187)

## 详细组件分析

### 基础UI组件分析

#### 按钮组件
按钮组件通过`class-variance-authority`（cva）实现多变体支持，包括默认、破坏性、轮廓、次要、幽灵和链接等类型。组件支持不同尺寸（默认、小、大、图标）和禁用状态。通过`asChild`属性支持组合模式，允许将按钮样式应用于其他组件。

```mermaid
classDiagram
class Button {
+variant : "default"|"destructive"|"outline"|"secondary"|"ghost"|"link"
+size : "default"|"sm"|"lg"|"icon"
+asChild? : boolean
+className? : string
}
Button --> cva : "使用"
Button --> cn : "使用"
Button --> Slot : "条件渲染"
```

**图示来源**  
- [button.tsx](file://src/components/ui/button.tsx#L1-L48)
- [utils.ts](file://src/lib/utils.ts#L1-L7)

#### 卡片组件
卡片组件提供了一组结构化子组件，包括Card、CardHeader、CardTitle、CardDescription、CardContent和CardFooter。这种组合模式允许灵活构建各种卡片布局。组件默认包含边框、背景色、圆角和阴影，符合现代设计规范。

```mermaid
classDiagram
class Card {
+className? : string
}
class CardHeader {
+className? : string
}
class CardTitle {
+className? : string
}
class CardDescription {
+className? : string
}
class CardContent {
+className? : string
}
class CardFooter {
+className? : string
}
Card --> CardHeader
Card --> CardContent
Card --> CardFooter
CardHeader --> CardTitle
CardHeader --> CardDescription
```

**图示来源**  
- [card.tsx](file://src/components/ui/card.tsx#L1-L44)

#### 对话框组件
对话框组件基于Radix UI实现，提供完整的模态对话框功能。组件包含Overlay（遮罩层）、Content（内容区）、Header、Footer、Title和Description等部分。支持动画过渡和键盘交互，确保良好的可访问性。

```mermaid
classDiagram
class Dialog {
+open? : boolean
+onOpenChange? : (open : boolean) => void
}
class DialogTrigger {
触发器
}
class DialogPortal {
渲染容器
}
class DialogOverlay {
遮罩层
}
class DialogContent {
内容区域
}
class DialogHeader {
头部区域
}
class DialogFooter {
底部区域
}
class DialogTitle {
标题
}
class DialogDescription {
描述文本
}
Dialog --> DialogTrigger
Dialog --> DialogPortal
DialogPortal --> DialogOverlay
DialogPortal --> DialogContent
DialogContent --> DialogHeader
DialogContent --> DialogFooter
DialogHeader --> DialogTitle
DialogHeader --> DialogDescription
```

**图示来源**  
- [dialog.tsx](file://src/components/ui/dialog.tsx#L1-L96)

#### 表单组件
表单组件基于react-hook-form构建，提供完整的表单管理解决方案。组件包含Form、FormField、FormItem、FormLabel、FormControl、FormDescription和FormMessage等部分，支持表单验证、错误提示和无障碍访问。

```mermaid
sequenceDiagram
participant Form as "Form"
participant FormField as "FormField"
participant FormItem as "FormItem"
participant FormLabel as "FormLabel"
participant FormControl as "FormControl"
participant FormMessage as "FormMessage"
Form->>FormField : 提供表单上下文
FormField->>FormItem : 创建表单项
FormItem->>FormLabel : 渲染标签
FormItem->>FormControl : 渲染控件
FormItem->>FormMessage : 渲染错误信息
FormControl->>FormContext : 同步值
FormContext->>FormMessage : 提供错误状态
```

**图示来源**  
- [form.tsx](file://src/components/ui/form.tsx#L1-L130)

### 布局组件分析

#### Header组件
Header组件作为应用的顶部导航栏，包含Logo和移动端菜单触发器。组件使用`next/navigation`的`usePathname`钩子来确定当前活动页面，并在移动端通过状态管理控制菜单的显示与隐藏。

```mermaid
flowchart TD
Start([组件挂载]) --> UsePathname["获取当前路径"]
UsePathname --> Render["渲染UI"]
Render --> CheckMobile["是否为移动设备?"]
CheckMobile --> |是| ShowMobileButton["显示移动菜单按钮"]
CheckMobile --> |否| ShowDesktopNav["显示桌面导航"]
ShowMobileButton --> HandleClick["点击按钮"]
HandleClick --> SetState["设置isMobileMenuOpen为true"]
SetState --> OpenMobileMenu["打开MobileMenu组件"]
```

**图示来源**  
- [Header.tsx](file://src/components/Layout/Header.tsx#L1-L51)
- [MobileMenu.tsx](file://src/components/Layout/MobileMenu.tsx#L1-L79)

#### MobileMenu组件
MobileMenu组件使用Sheet组件实现侧边抽屉式菜单。组件接收`isOpen`和`onOpenChange`作为受控属性，确保父组件可以控制菜单状态。菜单项根据当前路径高亮显示，提供良好的用户体验。

```mermaid
classDiagram
class MobileMenu {
+isOpen : boolean
+onOpenChange : (open : boolean) => void
}
class Sheet {
+open : boolean
+onOpenChange : (open : boolean) => void
}
class SheetContent {
+side : "left"|"right"|"top"|"bottom"
+className? : string
}
MobileMenu --> Sheet
Sheet --> SheetContent
SheetContent --> MenuItems
SheetContent --> LogoutButton
```

**图示来源**  
- [MobileMenu.tsx](file://src/components/Layout/MobileMenu.tsx#L1-L79)
- [sheet.tsx](file://src/components/ui/sheet.tsx#L1-L108)

#### SiteNavigation组件
SiteNavigation组件提供完整的导航功能，包含桌面端和移动端两种模式。桌面端使用常规链接导航，移动端通过MobileMenu组件实现响应式导航。组件统一管理导航状态和路径匹配逻辑。

```mermaid
flowchart TD
A[SiteNavigation] --> B[usePathname]
B --> C{路径匹配}
C --> D[生成导航项]
D --> E{屏幕尺寸}
E --> |大屏| F[渲染桌面导航]
E --> |小屏| G[渲染移动按钮]
G --> H[点击]
H --> I[打开MobileMenu]
I --> J[MobileMenu处理导航]
```

**图示来源**  
- [SiteNavigation.tsx](file://src/components/Layout/SiteNavigation.tsx#L1-L92)
- [MobileMenu.tsx](file://src/components/Layout/MobileMenu.tsx#L1-L79)

## 依赖分析

```mermaid
graph LR
A[ShadCN/UI组件] --> B[Tailwind CSS]
A --> C[Radix UI]
A --> D[class-variance-authority]
A --> E[clsx]
A --> F[tailwind-merge]
B --> G[CSS变量]
C --> H[可访问性]
D --> I[变体管理]
E --> J[类名合并]
F --> K[类名去重]
L[应用组件] --> A
L --> M[Next.js]
M --> N[React]
```

**图示来源**  
- [components.json](file://components.json#L1-L21)
- [tailwind.config.ts](file://tailwind.config.ts#L1-L121)
- [package.json](file://package.json)

## 性能考虑

组件库通过多种方式优化性能：使用`cn`工具函数高效合并类名，避免运行时性能开销；通过`React.forwardRef`正确传递引用；利用React的`React.memo`和`useCallback`等优化机制减少不必要的渲染。动画效果通过CSS过渡实现，确保流畅的用户体验。

## 故障排除指南

常见问题包括组件样式丢失、响应式失效和状态同步问题。确保`tailwind.config.ts`正确配置，`components.json`中的路径别名正确设置。对于状态同步问题，检查组件是否正确使用受控属性模式。样式问题通常源于CSS变量未正确定义或Tailwind JIT编译器未正确工作。

**本节来源**  
- [tailwind.config.ts](file://tailwind.config.ts#L1-L121)
- [components.json](file://components.json#L1-L21)
- [utils.ts](file://src/lib/utils.ts#L1-L7)

## 结论

TriBridge项目通过集成ShadCN/UI组件库，建立了统一、可维护的UI组件体系。组件设计注重可访问性、响应式和主题定制，支持快速构建一致的用户界面。布局组件通过状态管理实现跨页面复用，确保导航体验的一致性。整体架构清晰，依赖关系明确，为项目的持续开发提供了坚实的基础。