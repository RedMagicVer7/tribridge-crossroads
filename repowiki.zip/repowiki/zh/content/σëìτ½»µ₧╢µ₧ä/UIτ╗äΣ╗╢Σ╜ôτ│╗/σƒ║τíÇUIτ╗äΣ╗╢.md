# 基础UI组件

<cite>
**本文档引用文件**  
- [button.tsx](file://src/components/ui/button.tsx)
- [input.tsx](file://src/components/ui/input.tsx)
- [form.tsx](file://src/components/ui/form.tsx)
- [card.tsx](file://src/components/ui/card.tsx)
- [dialog.tsx](file://src/components/ui/dialog.tsx)
- [alert-dialog.tsx](file://src/components/ui/alert-dialog.tsx)
- [textarea.tsx](file://src/components/ui/textarea.tsx)
- [toast.tsx](file://src/components/ui/toast.tsx)
- [utils.ts](file://src/lib/utils.ts)
- [tailwind.config.ts](file://tailwind.config.ts)
- [components.json](file://components.json)
</cite>

## 目录
1. [简介](#简介)
2. [项目结构与设计系统集成](#项目结构与设计系统集成)
3. [核心UI组件详解](#核心ui组件详解)
4. [表单系统集成](#表单系统集成)
5. [对话框与提示框组件](#对话框与提示框组件)
6. [无障碍访问支持](#无障碍访问支持)
7. [样式定制与Tailwind集成](#样式定制与tailwind集成)
8. [常见问题与解决方案](#常见问题与解决方案)
9. [结论](#结论)

## 简介
本技术文档详细说明了TriBridge项目中基于ShadCN/UI构建的基础UI组件的实现原理、使用规范和集成方法。文档涵盖按钮、输入框、表单、卡片、对话框、提示框等原子级组件的技术细节，包括props接口定义、事件回调机制、样式继承机制以及无障碍访问支持。通过分析src/components/ui目录下的具体实现，阐述组件封装模式、Tailwind CSS类名合并机制以及与React Hook Form等表单库的集成方法。

## 项目结构与设计系统集成

```mermaid
graph TB
subgraph "UI组件层"
UI[ShadCN/UI组件]
Button[按钮组件]
Input[输入框组件]
Form[表单组件]
Card[卡片组件]
Dialog[对话框组件]
end
subgraph "工具层"
Utils[工具函数]
CN[cn函数]
Tailwind[Tailwind CSS]
end
subgraph "配置层"
ComponentsJson[components.json]
TailwindConfig[tailwind.config.ts]
end
UI --> Utils
Utils --> Tailwind
ComponentsJson --> UI
TailwindConfig --> Tailwind
```

**图示来源**  
- [components.json](file://components.json#L0-L20)
- [tailwind.config.ts](file://tailwind.config.ts#L0-L120)
- [utils.ts](file://src/lib/utils.ts#L0-L6)

**本节来源**  
- [components.json](file://components.json#L0-L20)
- [tailwind.config.ts](file://tailwind.config.ts#L0-L120)

## 核心UI组件详解

### 按钮组件（Button）
按钮组件采用React.forwardRef封装，支持多种变体（variant）和尺寸（size）配置。通过cva（Class Variant Authority）定义样式变体，使用cn函数合并类名。

```mermaid
classDiagram
class Button {
+variant : "default"|"destructive"|"outline"|"secondary"|"ghost"|"link"
+size : "default"|"sm"|"lg"|"icon"
+asChild : boolean
+className : string
}
Button --> "cva" buttonVariants
Button --> "cn" cn
Button --> "Slot" Slot
```

**图示来源**  
- [button.tsx](file://src/components/ui/button.tsx#L38-L43)
- [button.tsx](file://src/components/ui/button.tsx#L1-L47)

**本节来源**  
- [button.tsx](file://src/components/ui/button.tsx#L1-L47)

### 输入框组件（Input）
输入框组件封装了原生input元素，提供统一的样式和无障碍访问支持。组件自动应用基础样式，并通过className属性支持自定义扩展。

```mermaid
flowchart TD
Start([Input组件]) --> ApplyBaseStyle["应用基础样式"]
ApplyBaseStyle --> MergeClassName["合并自定义类名"]
MergeClassName --> RenderInput["渲染input元素"]
RenderInput --> End([完成渲染])
Note over ApplyBaseStyle,MergeClassName: 使用cn函数合并Tailwind类名
```

**图示来源**  
- [input.tsx](file://src/components/ui/input.tsx#L4-L18)
- [input.tsx](file://src/components/ui/input.tsx#L0-L22)

**本节来源**  
- [input.tsx](file://src/components/ui/input.tsx#L0-L22)

### 卡片组件（Card）
卡片组件由多个子组件构成，包括Card、CardHeader、CardTitle、CardDescription、CardContent和CardFooter，支持灵活的内容布局。

```mermaid
classDiagram
class Card {
+className : string
}
class CardHeader {
+className : string
}
class CardTitle {
+className : string
}
class CardDescription {
+className : string
}
class CardContent {
+className : string
}
class CardFooter {
+className : string
}
Card --> CardHeader
Card --> CardContent
Card --> CardFooter
CardHeader --> CardTitle
CardHeader --> CardDescription
```

**图示来源**  
- [card.tsx](file://src/components/ui/card.tsx#L4-L6)
- [card.tsx](file://src/components/ui/card.tsx#L0-L43)

**本节来源**  
- [card.tsx](file://src/components/ui/card.tsx#L0-L43)

## 表单系统集成

### React Hook Form集成
表单组件与React Hook Form深度集成，提供FormField、FormItem、FormLabel、FormControl、FormDescription和FormMessage等组件，实现表单状态管理和验证。

```mermaid
sequenceDiagram
participant Form as Form
participant FormField as FormField
participant Controller as Controller
participant Input as Input
Form->>FormField : 提供表单上下文
FormField->>Controller : 创建受控组件
Controller->>Input : 绑定输入值
Input->>Controller : 传递用户输入
Controller->>Form : 更新表单状态
Form->>FormMessage : 显示验证结果
```

**图示来源**  
- [form.tsx](file://src/components/ui/form.tsx#L0-L129)

**本节来源**  
- [form.tsx](file://src/components/ui/form.tsx#L0-L129)

### 文本域组件（Textarea）
文本域组件提供多行文本输入功能，支持自定义高度和样式扩展。

```mermaid
flowchart TD
TextareaStart([Textarea组件]) --> ApplyStyles["应用基础样式"]
ApplyStyles --> SetMinHeight["设置最小高度80px"]
SetMinHeight --> HandleResize["支持手动调整大小"]
HandleResize --> MergeClass["合并自定义类名"]
MergeClass --> RenderTextarea["渲染textarea元素"]
RenderTextarea --> TextareaEnd([完成渲染])
```

**图示来源**  
- [textarea.tsx](file://src/components/ui/textarea.tsx#L0-L21)

**本节来源**  
- [textarea.tsx](file://src/components/ui/textarea.tsx#L0-L21)

## 对话框与提示框组件

### 对话框组件（Dialog）
对话框组件提供模态对话框功能，包含触发器、内容区域、标题、描述和页脚等部分。

```mermaid
classDiagram
class Dialog {
+open : boolean
+onOpenChange : (open : boolean) => void
}
class DialogTrigger {
+asChild : boolean
}
class DialogContent {
+className : string
}
class DialogHeader {
+className : string
}
class DialogTitle {
+className : string
}
class DialogDescription {
+className : string
}
class DialogFooter {
+className : string
}
Dialog --> DialogTrigger
Dialog --> DialogContent
DialogContent --> DialogHeader
DialogContent --> DialogFooter
DialogHeader --> DialogTitle
DialogHeader --> DialogDescription
```

**图示来源**  
- [dialog.tsx](file://src/components/ui/dialog.tsx#L0-L95)

**本节来源**  
- [dialog.tsx](file://src/components/ui/dialog.tsx#L0-L95)

### 警告对话框组件（AlertDialog）
警告对话框组件专门用于需要用户确认的重要操作，提供"确认"和"取消"两个标准操作按钮。

```mermaid
classDiagram
class AlertDialog {
+open : boolean
+onOpenChange : (open : boolean) => void
}
class AlertDialogTrigger {
+asChild : boolean
}
class AlertDialogContent {
+className : string
}
class AlertDialogHeader {
+className : string
}
class AlertDialogTitle {
+className : string
}
class AlertDialogDescription {
+className : string
}
class AlertDialogFooter {
+className : string
}
class AlertDialogAction {
+className : string
}
class AlertDialogCancel {
+className : string
}
AlertDialog --> AlertDialogTrigger
AlertDialog --> AlertDialogContent
AlertDialogContent --> AlertDialogHeader
AlertDialogContent --> AlertDialogFooter
AlertDialogHeader --> AlertDialogTitle
AlertDialogHeader --> AlertDialogDescription
AlertDialogFooter --> AlertDialogAction
AlertDialogFooter --> AlertDialogCancel
```

**图示来源**  
- [alert-dialog.tsx](file://src/components/ui/alert-dialog.tsx#L0-L104)

**本节来源**  
- [alert-dialog.tsx](file://src/components/ui/alert-dialog.tsx#L0-L104)

### 提示框组件（Toast）
提示框组件提供轻量级的消息通知功能，支持默认和破坏性（destructive）两种变体。

```mermaid
classDiagram
class ToastProvider {
+children : ReactNode
+swipeDirection : "x"|"y"
+swipeThreshold : number
}
class ToastViewport {
+className : string
}
class Toast {
+variant : "default"|"destructive"
+className : string
}
class ToastTitle {
+className : string
}
class ToastDescription {
+className : string
}
class ToastAction {
+className : string
}
class ToastClose {
+className : string
}
ToastProvider --> ToastViewport
ToastViewport --> Toast
Toast --> ToastTitle
Toast --> ToastDescription
Toast --> ToastAction
Toast --> ToastClose
```

**图示来源**  
- [toast.tsx](file://src/components/ui/toast.tsx#L0-L111)

**本节来源**  
- [toast.tsx](file://src/components/ui/toast.tsx#L0-L111)

## 无障碍访问支持
所有UI组件均遵循WAI-ARIA标准，提供完整的无障碍访问支持。组件通过aria-*属性、语义化HTML标签和键盘导航支持，确保残障用户能够正常使用界面。

**本节来源**  
- [button.tsx](file://src/components/ui/button.tsx#L1-L47)
- [input.tsx](file://src/components/ui/input.tsx#L0-L22)
- [dialog.tsx](file://src/components/ui/dialog.tsx#L0-L95)
- [alert-dialog.tsx](file://src/components/ui/alert-dialog.tsx#L0-L104)

## 样式定制与Tailwind集成

### 类名合并机制
组件使用cn函数（基于clsx和tailwind-merge）合并类名，确保Tailwind CSS类名正确覆盖和优先级处理。

```mermaid
flowchart LR
A[基础样式] --> B[cn函数]
C[变体样式] --> B
D[自定义类名] --> B
B --> E[最终类名]
style A fill:#f9f,stroke:#333
style C fill:#f9f,stroke:#333
style D fill:#f9f,stroke:#333
style B fill:#bbf,stroke:#333,color:#fff
style E fill:#9f9,stroke:#333
```

**图示来源**  
- [utils.ts](file://src/lib/utils.ts#L0-L6)
- [button.tsx](file://src/components/ui/button.tsx#L1-L47)

**本节来源**  
- [utils.ts](file://src/lib/utils.ts#L0-L6)

### 主题变量配置
项目通过CSS变量定义主题颜色，在tailwind.config.ts中引用这些变量，实现设计系统的一致性。

**本节来源**  
- [tailwind.config.ts](file://tailwind.config.ts#L0-L120)

## 常见问题与解决方案

### 样式冲突
当自定义样式与组件默认样式冲突时，建议使用更高优先级的选择器或在tailwind.config.ts中调整配置。

### 响应式断点失效
确保在tailwind.config.ts的content配置中正确包含组件文件路径，以便Tailwind能够扫描并生成相应的响应式类名。

**本节来源**  
- [tailwind.config.ts](file://tailwind.config.ts#L0-L120)
- [components.json](file://components.json#L0-L20)

## 结论
TriBridge项目通过ShadCN/UI构建了一套完整的基础UI组件库，这些组件具有良好的可复用性、可访问性和可定制性。通过合理的封装模式和Tailwind CSS集成，实现了设计系统的一致性和开发效率的提升。